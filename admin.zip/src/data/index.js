import mock from "./mock";
import "./todo/TodoData";
mock.onAny().passThrough();
