import React, { useEffect, useState } from "react";
import { useDispatch, useSelector } from "react-redux";
import { Card, CardBody, CardTitle, Col, Progress, Row } from "reactstrap";
import CardHeader from "reactstrap/lib/CardHeader";
import { imagenesUrl } from "../../../redux/config/configuraciones";
import { getProductsAction } from "../../../../src/redux/actions/votapoliticos/VotacionesActions";
import server from "../../../redux/config/server";

import "./styless2.css";
import logo from "../../../assets/emprendimientos_virtuales/images/solofans/logo-menu.png";
import { Link } from "react-router-dom";

const VisitCountries = () => {
  const [id, setId] = useState();
  const [selects, setSelects] = useState(undefined);
  const currentUser = JSON.parse(localStorage.getItem("currentUser"));
  const API = server.baseURL + "/votapoliticos/informes/listaDeCargos";
  //mandar a llamar la accion principal para retornar los productos
  const dispatch = useDispatch();
  useEffect(() => {
    //productos cuando el componente este listo

    fetch(API, {
      method: "GET",
      headers: {
        Token: `Bearer ${currentUser.data.token}`,
        rol: currentUser.data.rol,
      },
    })
      .then((response) => response.json())
      .then((data) => {
        setSelects(data.data);
      })

      .catch((error) => {
        console.log(error);
      });
  }, []);
  //acceder al state
  const loading = useSelector((state) => state.productsReducer.loading);
  const error = useSelector((state) => state.productsReducer.error);
  const productsReducer = useSelector(
    (state) => state.productsReducer.products
  );
  const informesList = (id) => {
    dispatch(getProductsAction(id));
    setId(id);
    console.log("entro", id);
  };

  const ref = React.createRef();
  const options = {
    orientation: "landscape",
    unit: "in",
    format: [4, 2],
  };
  console.log("dta list", productsReducer);

  return (
    <Card>
      <CardHeader>
        <div className="form-group">
          <div className="ml-auto">
            <small>Seleccione la votación</small>

            {!selects ? (
              <div className="imagen-home-promociones1-oculto"></div>
            ) : (
              <div>
                <select
                  className="form-control"
                  onChange={(e) => informesList(e.target.value)}
                >
                  <option value="">Seleccioné</option>
                  {selects.map((eleccion) => {
                    return (
                      <optgroup
                        label={
                          eleccion.nombre_eleccion +
                          " / " +
                          eleccion.fecha
                            .split(" ")[0]
                            .split("-")
                            .reverse()
                            .join("-")
                        }
                      >
                        {eleccion.cargos.map((cargo) => {
                          return (
                            <option value={cargo.id_elec_cargo}>
                              {cargo.nombre_cargo}
                            </option>
                          );
                        })}
                      </optgroup>
                    );
                  })}
                </select>
              </div>
            )}
          </div>
        </div>

        <a
          href={`${server.baseURL}/votapoliticos/informes/resultados/pdf/${id}`}
          target="_blank"
        >
          <button className="btn btn-primary ">Generate Pdf</button>
        </a>
      </CardHeader>
      <div>
        {!productsReducer.detalle ? (
          <div className="imagen-home-promociones1-oculto"></div>
        ) : (
          <div
            style={{ padding: "0.5rem" }}
            ref={ref}
            options={options}
            style={{ width: "80%" }}
          >
            {/* <header style={{display:"flex",justifyContent:"center",alignContent:"center"}}>
              <img src={logo} alt="Emprendimientos" className="logo" />
            </header> */}
            <CardTitle className="text-uppercase text-center">
              {productsReducer.cabecera.nombre_cargo}
            </CardTitle>
            <div
              style={{
                display: "flex",
                justifyContent: "center",
                flexDirection: "row",
              }}
            >
              <h5>Total Votos: {productsReducer.cabecera.total_votos}</h5>

              <h5 style={{ marginLeft: "1rem" }}>
                Total Votantes: {productsReducer.cabecera.total_votantes}
              </h5>

              {productsReducer.cabecera.votos_blancos_elec_cargo == "1" && (
                <h5 style={{ marginLeft: "1rem" }}>
                  Votos blancos: {productsReducer.extra.blanco}
                </h5>
              )}
              <h5 style={{ marginLeft: "1rem" }}>
                Votos nulos: {productsReducer.extra.nulo}
              </h5>
              {/* {productsReducer.cabecera.votos_nulos_elec_cargo == "1" && (
                <h5 style={{ marginLeft: "1rem" }}>
                  Votos nulos: {productsReducer.extra.nulo}
                </h5>
              )} */}
            </div>
            {productsReducer.detalle.map((informes) => {
              var totalVotos =
                productsReducer.cabecera.total_votos == 0
                  ? 1
                  : productsReducer.cabecera.total_votos;
              return (
                <ul className="list-style-none country-state ">
                  <li
                    style={{
                      // backgroundColor: `${productsReducer.cabecera.color_elec_cargo}`,
                      borderRadius: "1rem",
                      padding: "0.3rem",
                      marginBottom: "0.1rem",
                    }}
                  >
                    <div className="d-flex align-items-center">
                      <small style={{ display: "flex", flexDirection: "row" }}>
                        <div style={{ display: "flex", alignItems: "center" }}>
                          <img
                            src={`${imagenesUrl}/votapoliticos/sm/politicos/${informes.imagen_politico}`}
                            alt="logo"
                            className="img-pol"
                          />
                        </div>
                        <br /> <br />
                        <div>
                          <h4
                            className="color-white"
                            style={{ marginLeft: "1rem" }}
                          >
                            {informes.nombre_politico +
                              " " +
                              informes.apellido_politico}
                          </h4>
                          <div className="row">
                            <div
                              style={{
                                display: "flex",
                                flexDirection: "column",
                                marginLeft: "1rem",
                              }}
                            >
                              <h5 style={{ marginLeft: "1rem" }}>
                                Votos obtenidos:
                              </h5>

                              <h5 style={{ marginLeft: "1rem" }}>
                                {informes.cantidad}
                              </h5>
                            </div>
                            <div
                              style={{
                                display: "flex",
                                flexDirection: "column",
                                marginLeft: "1rem",
                              }}
                            >
                              <h5 style={{ marginLeft: "1rem" }}>
                                Porcentaje:{" "}
                              </h5>
                              <h5 style={{ marginLeft: "1rem" }}>
                                {" "}
                                {(
                                  (parseInt(informes.cantidad) /
                                    parseInt(totalVotos)) *
                                  100
                                ).toFixed(2)}
                                %
                              </h5>
                            </div>
                          </div>
                        </div>
                      </small>
                    </div>
                  </li>
                  <hr />
                </ul>
              );
            })}
          </div>
        )}
      </div>
    </Card>
  );
};

export default VisitCountries;
