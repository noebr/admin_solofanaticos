import React from "react";
import Pdf from "react-to-pdf";
import "./styless2.css";
import imagen from "../../../assets/emprendimientos_virtuales/img-pol.jpg";
import logo from "../../../assets/emprendimientos_virtuales/images/solofans/logo-menu.png";

const ref = React.createRef();
const options = {
  orientation: "landscape",
  unit: "in",
  format: [4, 2],
};

function Demo() {
  return (
    <div className="App">
      <Pdf targetRef={ref} filename="code-example.pdf">
        {({ toPdf }) => (
          <button onClick={toPdf} className="btn btn-primary ">
            Generate Pdf
          </button>
        )}
      </Pdf>
      <br />
      <br />

        <div ref={ref} options={options} style={{ width: "80%" }}>
          <header>
            <img src={logo} alt="Emprendimientos" className="logo" />
          </header>
          <main>
            <div>
              <h1 className="h1-4">Consejo de administración</h1>
              <div className="resum-1">
                <h5 className="li-re">Cantidad de Votantes: 0</h5>

                <h5 className="li-re">Votos blancos: 0</h5>
                <h5 className="li-re">Votos nulos: 0</h5>
              </div>
              <ul className="list-style-none country-state ">
                <li className="li-re2">
                  <div className="d-flex align-items-center">
                    <small className="title-re2">
                      <div className="content-re2">
                        <img src={imagen} alt="logo" className="img-pol" />
                      </div>
                      <br /> <br />
                      <div>
                        <h4 className="tit">Jorge Rios</h4>

                        <div className="row2">
                          <div className="row-re">
                            <div>
                              <h4 className="tit">Total votos:</h4>

                              <h4 className="tit2">23000</h4>
                            </div>
                            <div className="row-3">
                              <h4 className="tit">Porcentaje:</h4>

                              <h4 className="tit2">50 %</h4>
                            </div>
                          </div>
                        </div>
                      </div>
                    </small>
                  </div>
                </li>
                <hr />
              </ul>
            </div>
            <div className="firmas">
              <p className="firma">Firma</p>
              <p className="firma">Aclaración</p>
              <p className="firma">Fecha</p>
            </div>
          </main>
        </div>

    </div>
  );
}
export default Demo;
