import React, { useEffect, useState } from "react";
import { useDispatch, useSelector } from "react-redux";
import { Card, CardBody, CardTitle, Col, Progress, Row } from "reactstrap";
import CardHeader from "reactstrap/lib/CardHeader";
import { imagenesUrl } from "../../../redux/config/configuraciones";
import { getProductsAction } from "../../../../src/redux/actions/votapoliticos/VotacionesActions";
import server from "../../../redux/config/server";
import ReactToPdf from "react-to-pdf";
import { Page, Text, View, Document, StyleSheet } from '@react-pdf/renderer';

const VisitCountries = () => {
  const [selects, setSelects] = useState(undefined);
  const currentUser = JSON.parse(localStorage.getItem("currentUser"));
  const API = server.baseURL + "/votapoliticos/informes/listaDeCargos";
  //mandar a llamar la accion principal para retornar los productos
  const dispatch = useDispatch();
  useEffect(() => {
    //productos cuando el componente este listo

    fetch(API, {
      method: "GET",
      headers: {
        Token: `Bearer ${currentUser.data.token}`,
        rol: currentUser.data.rol,
      },
    })
      .then((response) => response.json())
      .then((data) => {
        setSelects(data.data);
      })

      .catch((error) => {
        console.log(error);
      });
  }, []);
  //acceder al state
  const loading = useSelector((state) => state.productsReducer.loading);
  const error = useSelector((state) => state.productsReducer.error);
  const productsReducer = useSelector(
    (state) => state.productsReducer.products
  );
  const informesList = (id) => {
    dispatch(getProductsAction(id));

    console.log("entro", id);
  };
  console.log("dta list", productsReducer);
  // Create styles
const styles = StyleSheet.create({
  page: {
    flexDirection: 'row',
    backgroundColor: '#E4E4E4'
  },
  section: {
    margin: 10,
    padding: 10,
    flexGrow: 1
  }
});
  return (
    <Card>
      <CardHeader>
        <div className="form-group">
          <div className="ml-auto">
            <small>Seleccione el cargo</small>

            {!selects ? (
              <div className="imagen-home-promociones1-oculto"></div>
            ) : (
              <div>
                <select
                  className="form-control"
                  onChange={(e) => informesList(e.target.value)}
                >
                  <option value="">Seleccioné</option>
                  {selects.map((eleccion) => {
                    return (
                      <optgroup
                        label={
                          eleccion.nombre_eleccion + " / " + eleccion.fecha.split(" ")[0].split("-").reverse().join("-")
                        
                        }
                      >
                        {eleccion.cargos.map((cargo) => {
                          return (
                            <option value={cargo.id_elec_cargo}>
                              {cargo.nombre_cargo}
                            </option>
                          );
                        })}
                      </optgroup>
                    );
                  })}
                </select>
              </div>
            )}
          </div>
        </div>
      </CardHeader>
      <div>
      {!productsReducer.detalle ? (
        <div className="imagen-home-promociones1-oculto"></div>
      ) : (
        <div style={{ padding: "0.5rem" }}>
          <CardTitle className="text-uppercase text-center">
            {productsReducer.cabecera.nombre_cargo}
          </CardTitle>
          <div
            style={{
              display: "flex",
              justifyContent: "center",
              flexDirection: "row",
            }}
          >
            <h5>Cantidad de Votantes: {productsReducer.cabecera.total_votos}</h5>
            {productsReducer.cabecera.votos_blancos_elec_cargo == "1" && (
              <h5 style={{ marginLeft: "1rem" }}>
                Votos blancos: {productsReducer.extra.blanco}
              </h5>
            )}
            {productsReducer.cabecera.votos_nulos_elec_cargo == "1" && (
              <h5 style={{ marginLeft: "1rem" }}>
                Votos nulos: {productsReducer.extra.nulo}
              </h5>
            )}
          </div>
          {productsReducer.detalle.map((informes) => {
            var totalVotos =
              productsReducer.cabecera.total_votos == 0
                ? 1
                : productsReducer.cabecera.total_votos;
            return (
              <ul className="list-style-none country-state ">
                <li
                  style={{
                    backgroundColor: `${productsReducer.cabecera.color_elec_cargo}`,
                    borderRadius: "1rem",
                    padding: "0.3rem",
                    marginBottom: "0.1rem",
                  }}
                >
                  <div className="d-flex align-items-center">
                    <small style={{ display: "flex", flexDirection: "row" }}>
                      <div style={{ display: "flex", alignItems: "center" }}>
                        <img
                          src={`${imagenesUrl}/votapoliticos/sm/politicos/${informes.imagen_politico}`}
                          alt="logo"
                          style={{ width: "3rem", borderRadius: "50%" }}
                        />
                      </div>
                      <br /> <br />
                      <div>
                        <h4
                          className="color-white"
                          style={{ marginLeft: "1rem" }}
                        >
                          {informes.nombre_politico +
                            " " +
                            informes.apellido_politico}
                        </h4>
                        <h5
                          style={{ marginLeft: "1rem" }}
                          style={{ marginLeft: "1rem" }}
                        >
                          Votos obtenidos: {informes.cantidad}
                        </h5>
                      </div>
                    </small>

                    <div className="ml-auto">
                      <h4 className="h1-1">
                        {parseInt(
                          (parseInt(informes.cantidad) / parseInt(totalVotos)) *
                            100
                        )}
                        %
                      </h4>
                    </div>
                  </div>
                </li>
              </ul>
            );
          })}
        </div>
      )}
      
      </div>

    </Card>
  );
};

export default VisitCountries;
